/**
 * Provides utility classes.
 */
package fr.tikione.ini.util;
