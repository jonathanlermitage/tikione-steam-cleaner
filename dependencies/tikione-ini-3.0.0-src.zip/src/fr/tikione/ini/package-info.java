/**
 * Provides main classes to work with INI files.
 */
package fr.tikione.ini;
